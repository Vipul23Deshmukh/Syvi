import React, { useEffect, useState, useRef } from "react";
//import { useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import CryptoJS from "crypto-js";
import AdminPage from './AdminPage';
//import "./styles.css";

//import './components/ChatbotIcon.jsx';

const App = () => {
 // const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [userName, setUserName] = useState(localStorage.getItem("userName"));
  const [isAdmin, setIsAdmin] = useState(localStorage.getItem("isAdmin") === "true");
  const [view, setView] = useState('chat'); // 'chat' | 'login' | 'signup' | 'history' | 'Admin_Page'
  const [showDropdown, setShowDropdown] = useState(false);
  const [showCreateAdmin, setShowCreateAdmin] = useState(false);
  const [historyData, setHistoryData] = useState([]);
  const recognitionRef = useRef(null);
  const messagesEndRef = useRef(null);
  const [users, setUsers] = useState([]);
  //const [filteredUsers, setUsers] = useState([]);
  const [prompts, setPromptData] = useState([]);
  const [promptType, setPromptType] = useState("public");
  const [editPrompt, setEditPrompt] = useState('');
  const [selectedPromptId, setSelectedPromptId] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.lang = 'en-US'; 
  const SECRET_KEY = "e+4E3zQ51BVMUnhpRrUkO8FsXhR1djjgFx4+Jw71Hes="; // must match backend

  const key = CryptoJS.enc.Base64.parse(SECRET_KEY);

  function encryptCBC(data) {
    const iv = CryptoJS.lib.WordArray.random(16); // 128-bit IV
    const encrypted = CryptoJS.AES.encrypt(JSON.stringify(data), key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });
  
    return {
      ciphertext: encrypted.ciphertext.toString(CryptoJS.enc.Base64),
      iv: iv.toString(CryptoJS.enc.Hex) // send IV along with ciphertext
    };
  }

  useEffect(() => {
    updateLoginState();
    
  }, []);

  const scrollToBottom = () => {
    const lastMsg = messages[messages.length -1];
  if (lastMsg && lastMsg.type === "bot") {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }
  };

  const updateLoginState = () => {
    const storedUserName = localStorage.getItem("Name");
    
    setUserName(storedUserName);
    setIsAdmin(localStorage.getItem("isAdmin") === "true");

  };

  const handleSend = async () => {
    if (!input.trim()) return;
    appendMessage(input, "user");
    await handleUserInput(input);
    setInput("");
  };

  const appendMessage = (text, type) => {
    setMessages((prev) => [...prev, { text, type }]);
    scrollToBottom();
  };

  const handleUserInput = async (text) => {
    const token = localStorage.getItem("token");
    //  console.log(token);
    
    let apiUrl, options;

    if (token) {
      apiUrl = 'http://localhost:8081/chatbot/ai/ask-ai';
      options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ question: text }),
      };
    } else {
      apiUrl = `http://localhost:8081/chatbot/public/ask-ai?query=${encodeURIComponent(text)}`;
      options = { method: "GET" };
    }

    try {
      const res = await fetch(apiUrl, options);
      const data = await res.json();
      // console.log(data.responseText);
      
      appendMessage(data.responseText || "No response received", "bot");
      
    } catch (error) {
      console.error("Error fetching response:", error);
      appendMessage("Error fetching response. Please try again.", "bot");
    }
  };

  const formatBotMessage = (text) => {
    if (!text) return "";
  
    let escaped = text
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  
    return escaped
      .replace(/\\n/g, "<br />")
      .replace(/\n/g, "<br />")
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/```(.*?)```/gs, "<pre><code>$1</code></pre>")
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
      .replace(/- (.*?)(<br \/>|$)/g, "• $1<br />");
  };
  

  const handleLogin = async ({email, password}) => {
    try {
      const { ciphertext, iv } = encryptCBC({ email, password });
      const response = await fetch("http://localhost:8081/chatbot/public/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ciphertext: ciphertext, iv:iv }),
      });
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("token", data.token);
        // console.log("before decoding :- ");
        const decoded = jwtDecode(data.token);
        // console.log("Decoded JWT:", decoded);
        localStorage.setItem("isAdmin", decoded.isAdmin);
        localStorage.setItem("userName", decoded.sub);
        localStorage.setItem("Name", decoded.Name);
        setUserName(decoded.Name);
        setIsAdmin(decoded.isAdmin);
        setView('chat');
        alert("Login successful");
       // useEffect;
      } else {
        alert(data.token || "Login failed");
      }
    } catch (err) {
      alert("Error logging in");
    }
  };

  const handleSignup = async ({ name, email, password, confirmPassword }) => {
    if (password !== confirmPassword) return alert("Passwords do not match");
    try {
      const { ciphertext, iv } = encryptCBC({name, email, password });
      const res = await fetch("http://localhost:8081/chatbot/public/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ciphertext: ciphertext, iv:iv }),
      });
      const data = await res.text();
      if (res.ok) {
        alert("Signup successful. Please log in.");
        setView('login');
      } else {
        alert(data || "Signup failed");
      }
    } catch (err) {
      alert("Error signing up");
    }
  };

  const handleVerifyOtp = async ({email , otp}) => {
    try {
      const { ciphertext, iv } = encryptCBC({ email, otp });
      const res = await fetch("http://localhost:8081/chatbot/public/verify-otp", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ciphertext: ciphertext, iv:iv }),
      });
      if (res.ok) {
        alert("OTP Verified");
        setOtpVerified(true);
      } else {
        alert("Invalid OTP");
      }
    } catch (error) {
      console.error("OTP verification error:", error);
    }
  };

  const handleSendOtp = async ({email}) => {
    if (!email) {
      alert("Please enter your email first.");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8081/chatbot/public/generate-otp?email=${email}`, {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      });

      const data = await response.text();
      if (response.ok) {
        setOtpSent(true);
        alert("OTP sent to your email.");
      } else {
        alert(data.message || "Failed to send OTP.");
      }
    } catch (err) {
      console.error("OTP Error:", err);
      alert("Error sending OTP.");
    }
  };


  const createAdmin = async (name, email, password) => {
    const token = localStorage.getItem("token");
    const { ciphertext, iv } = encryptCBC({name, email, password });
    try {
      const res = await fetch("http://localhost:8081/chatbot/admin/create-admin-user", {
       
        method: "POST",
        headers: { 'Content-Type': 'application/json', 
          Authorization: `Bearer ${token}` 
        },
        body: JSON.stringify({ ciphertext: ciphertext, iv:iv }),
      });
      if (res.ok) {
        alert("Admin created successfully");
        setName(''); setEmail(''); setPassword('');
      } else {
        alert("Failed to create admin");
      }
    } catch (err) {
      console.error("Error creating admin:", err);
    }
  };

  const updatePrompt = async (editPrompt, promptType) => {
    const token = localStorage.getItem("token");
    try {
      const res = await fetch(`http://localhost:8081/chatbot/admin/update-prompt?type=${promptType}`, {
        method: "POST",
        headers: { 'Content-Type': 'application/json',
           Authorization: `Bearer ${token}` 
          },
           body: JSON.stringify({ promptContent: editPrompt }),
      });
      const data = await response.text();
      console.log(data);
      
      if (res.ok) {
        alert("Prompt updated successfully");
        setEditPrompt('');
        setEditPrompt('');
      }
      else {
        alert("Failed to update prompt.");
      }
    } catch (err) {
      console.error("Error updating prompt:", err);
      alert("Something went wrong while updating the prompt.");
    }
  };

  const fetchHistory = async () => {
    const token = localStorage.getItem("token");
    const page = 0;
    const size = 100;
    try {
      const res = await fetch(`http://localhost:8081/chatbot/ai/chat-history?page=${page}&size=${size}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await res.json();
      setHistoryData(data.content);
      setView("history");
    } catch (error) {
      console.error("Error fetching history:", error);
    }
  };

  const fetchAllUsers = async () => {
    const token = localStorage.getItem("token");
   // if (!isAdmin) return alert("Unauthorized access!");

    try {
      const res = await fetch("http://localhost:8081/chatbot/admin/all-users", {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      // Filter out entries that don't have proper fullName or userName
    const filteredUsers = data.filter(user => user.fullName && user.userName);

      setUsers(filteredUsers);
    } catch (err) {
      console.error("Failed to fetch users:", err);
    }
  };

  const startRecording = () => {
    if (!userName) return; // Only allow voice if logged in
    setIsRecording(true);
    recognition.start();
  
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      //console.log("Voice input:", transcript);
      // setInput(transcript); // fill input box
      appendMessage(transcript,'user'); // or auto-send
      handleUserInput(transcript);
    };
  
    recognition.onerror = (event) => {
      console.error("Speech recognition error:", event.error);
      setIsRecording(false);
    };
  
    recognition.onend = () => {
      setIsRecording(false);
    };
  };
  
  const stopRecording = () => {
    setIsRecording(false);
    recognition.stop();
  };
  
  const toggleDropdown = () => {
    setShowDropdown(prev => !prev);
  };

  const handleLogout = () => {
    localStorage.clear();
    setUserName(null);
    setIsAdmin(false);
    location.reload();
    //navigate("/login");
  };

  if (view === 'login') {
    return (
      <div className="auth-container">
      <h2>Login</h2>
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={() => handleLogin({ email, password })}>Login</button>
      <p >Don't have an account?<a href="#" onClick={() => setView('signup')}>Sign up</a>
      </p>
    </div>
    );
  };

  if (view === 'signup') {
    return (
      <div className="auth-container">
      <h2>Signup</h2>

      <input type="text" placeholder="Full Name" value={name} onChange={(e) => setName(e.target.value)} />

      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />

      <button className="btn btn-sm btn-outline-primary" onClick={() => handleSendOtp({email})}>
        Generate OTP
        </button>
      

      {otpSent && (
        <>
          <input type="text" placeholder="Enter 6-digit OTP" value={otp} onChange={(e) => setOtp(e.target.value)} />
          <button className="btn btn-sm btn-outline-success" onClick={() => handleVerifyOtp({email, otp})}>Verify</button>
        </>
      )}

      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />

      <input type="password" placeholder="Confirm Password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />

      <button
        onClick={() => handleSignup({ name, email, password, confirmPassword })}
        disabled={!otpVerified}
        className="btn btn-primary"
      >
        Signup                                                                        
      </button>

      <p>
        Already have an account? <a href="#" onClick={() => setView('login')}>Login</a>
      </p>
    </div>
    );
  };
  
  if (view === 'Admin_Page'){
    return (
      <div className="admin-popup-overlay">
      <div className="admin-popup">

        <div className="chat-header">
        <button className="close-button" onClick={() => setView('chat')}>✖</button>
        <h2 className="mb-4">Admin Dashboard</h2>
        </div>

        <div className="container">
        <h4 className="mb-3 text-primary">All Registered Users</h4>
        <ul className="list-group mb-4">
        {users.map(user => (
          user.fullName && user.userName && (
          <li
          key={user.id.timestamp}
          className="list-group-item d-flex justify-content-between align-items-center"
          >
          <div>
          <strong className="text-dark">{user.fullName}</strong>
            <div className="text-muted small">{user.userName}</div>
            </div>
          </li>
          )))}
        </ul>
        </div>

        <div  className="container">
        <h4>Create New Admin</h4>
        <button
          className="btn btn-outline-primary mb-3"
          onClick={() => setShowCreateAdmin(prev => !prev)}
          >
        {showCreateAdmin ? "Hide Form" : "Create New Admin"}
        </button>

        {showCreateAdmin && (
          <div className="admin_form">
         <div className="mb-4">
         <input className="form-control mb-2" type="text" placeholder="Name" value={name} onChange={e => setName(e.target.value)}/>
         <input className="form-control mb-2" type="email" placeholder="Email" value={email}
                onChange={e => setEmail(e.target.value)}/>
          <input className="form-control mb-2" type="password" placeholder="Password" value={password}
               onChange={e => setPassword(e.target.value)}/>
          <button className="btn btn-primary" onClick={() => createAdmin(name, email, password)}>
            Create Admin
          </button>
          </div>
          </div>
        )}
        </div>

        
        <div  className="container">
        <h4 className="mb-3">Add / Edit Prompt</h4>

        <div className="card p-3 mb-4 shadow-sm">
        <div className="form-group mb-3">
        <label htmlFor="promptType"><strong>Select Prompt Type:</strong></label>
        <select
          id="promptType"
          className="form-select"
          value={promptType}
          onChange={(e) => setPromptType(e.target.value)}
          >
          <option value="">-- Choose Prompt Type --</option>
          <option value="public">Public</option>
          <option value="internal">Internal</option>
          </select>
        </div>

        <div className="form-group mb-3">
        <label htmlFor="promptContent"><strong>Prompt Content:</strong></label>
        <textarea
          id="promptContent"
          className="form-control"
          rows="5"
          placeholder="Enter the prompt here..."
          value={editPrompt}
          onChange={(e) => setEditPrompt(e.target.value)}
        />
        </div>

         <button
          className="btn btn-success"
          disabled={!promptType || !editPrompt.trim()}
         onClick={() => updatePrompt(editPrompt, promptType)}
         >
        Update Prompt
        </button>
        </div> 
        </div>      
        </div>
        </div>

       );
  };

  if (view === 'history') {
    return (
      <div className="chat-container">
        <div className="chat-header">
        <button className="back-btn1" onClick={() => setView('chat')}>🡐</button>
        <h2 className="chatbot-logo text-center flex-grow-1">
          History
          </h2>
          
        </div>
        <div className="chat-messages">
          {historyData.map((entry, idx) => (
          <div key={idx} className="message">
          <div><strong>Q:</strong> {entry.questionText}</div>
          <div
       ><strong>A:</strong> <span dangerouslySetInnerHTML={{ __html: formatBotMessage(entry.responseText) }} /></div>
          <div className="timestamp">{new Date(entry.timestamp).toLocaleString()}</div>
          </div>
          ))}
        </div>
      </div>
    );
  };

if(view === 'chat'){
  return ( 
    
    <div className="chat-container">
    <div className="chat-header d-flex justify-content-between align-items-center px-3">
    
      {userName ? (
        <div className="options-dropdown">
          <button className="menu-button" onClick={toggleDropdown}>☰</button>
          {showDropdown && (
          <div className="dropdown-content">
            <p ><strong>{userName}</strong></p>
            <button onClick={fetchHistory}>History</button>
            {isAdmin && <button onClick={() => {setView('Admin_Page');
               fetchAllUsers();
              //   fetchPrompts();
                }}>
                  Admin Page
                  </button>}
            <button onClick={handleLogout}>Logout</button>
          </div>
          )}
        </div>
      ) : (
        <div /> // empty div to reserve space if needed
      )}

      <h2 className="chatbot-logo text-center flex-grow-1">
      <i className="bi bi-robot"></i>SYVI
      </h2>

      {/* 👇 Only show this if user is NOT logged in */}
      {!userName && (
        <button className="login-btn1" onClick={() => setView('login')}>
          LogIn/SignUp
        </button>
      )}
    </div>     
        
          <div className="chat-messages">
          {messages.map((msg, index) => (
          msg.type === 'bot' ? (
          <div
          key={index}
          className={`message bot-message`}
          dangerouslySetInnerHTML={{ __html: formatBotMessage(msg.text) }}
            />
           ) : (
           <div key={index} className={`message ${msg.type}-message`}>
           {msg.text}
           </div>
           )
           ))}
          <div ref={messagesEndRef} />
          </div >
          <div className="chat-input">
            <input
              className="input-field"
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
            />
            <button className="send-button" onClick={handleSend}>⮞</button>
            {userName && (
              <button
              className={`mic-button ${isRecording ? 'recording' : ''}`}
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              title="Hold to speak"
            >
              🎙️
            </button>
                )}
          </div>
        
    </div>
  );
};
};


export default App;
