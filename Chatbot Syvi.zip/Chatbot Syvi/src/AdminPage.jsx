import React, { useEffect, useState } from 'react';

const AdminPage = () => {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [prompts, setPrompts] = useState([]);
  const [editPrompt, setEditPrompt] = useState('');
  const [selectedPromptId, setSelectedPromptId] = useState(null);

  const token = localStorage.getItem("token");

  const fetchUsers = async () => {
    try {
      const res = await fetch("http://localhost:8081/chatbot/admin/all-users", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      console.error("Failed to fetch users:", err);
    }
  };

  const createAdmin = async () => {
    try {
      const res = await fetch("http://localhost:8081/chatbot/admin/create", {
        method: "POST",
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name, email, password })
      });
      if (res.ok) {
        alert("Admin created successfully");
        setName(''); setEmail(''); setPassword('');
        fetchUsers();
      } else {
        alert("Failed to create admin");
      }
    } catch (err) {
      console.error("Error creating admin:", err);
    }
  };

  const fetchPrompts = async () => {
    try {
      const res = await fetch("http://localhost:8081/chatbot/admin/get-prompts", {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setPrompts(data);
    } catch (err) {
      console.error("Failed to fetch prompts:", err);
    }
  };

  const updatePrompt = async () => {
    try {
      const res = await fetch(`http://localhost:8081/chatbot/admin/edit-prompt/${selectedPromptId}`, {
        method: "PUT",
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ promptText: editPrompt })
      });
      if (res.ok) {
        alert("Prompt updated successfully");
        fetchPrompts();
        setEditPrompt('');
      }
    } catch (err) {
      console.error("Error updating prompt:", err);
    }
  };

  const deleteUser = async (userId) => {
    try {
      const res = await fetch(`http://localhost:8081/chatbot/admin/delete-user/${userId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        alert("User deleted");
        fetchUsers();
      }
    } catch (err) {
      console.error("Failed to delete user:", err);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchPrompts();
  }, []);

  return (
    <div className="container py-4">
      <h2 className="mb-4">Admin Dashboard</h2>

      <h4>All Users</h4>
      <ul className="list-group mb-4">
        {users.map(user => (
          <li key={user.id} className="list-group-item d-flex justify-content-between">
            {user.name} <button className="btn btn-danger btn-sm" onClick={() => deleteUser(user.id)}>Delete</button>
          </li>
        ))}
      </ul>

      <h4>Create New Admin</h4>
      <div className="mb-4">
        <input className="form-control mb-2" type="text" placeholder="Name" value={name} onChange={e => setName(e.target.value)} />
        <input className="form-control mb-2" type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <input className="form-control mb-2" type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
        <button className="btn btn-primary" onClick={createAdmin}>Create Admin</button>
      </div>

      <h4>Edit Prompts</h4>
      <ul className="list-group mb-3">
        {prompts.map(prompt => (
          <li key={prompt.id} className="list-group-item">
            <div><strong>{prompt.promptText}</strong></div>
            <button className="btn btn-sm btn-secondary mt-2" onClick={() => { setSelectedPromptId(prompt.id); setEditPrompt(prompt.promptText); }}>Edit</button>
          </li>
        ))}
      </ul>

      {selectedPromptId && (
        <div className="mb-3">
          <textarea className="form-control mb-2" value={editPrompt} onChange={e => setEditPrompt(e.target.value)} />
          <button className="btn btn-success" onClick={updatePrompt}>Save Changes</button>
        </div>
      )}
    </div>
  );
};

export default AdminPage;
