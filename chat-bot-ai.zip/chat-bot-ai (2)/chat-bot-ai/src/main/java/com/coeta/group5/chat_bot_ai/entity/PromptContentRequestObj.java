package com.coeta.group5.chat_bot_ai.entity;

public class PromptContentRequestObj {

    private String promptContent;

    public PromptContentRequestObj() {
    }

    public String getPromptContent() {
        return promptContent;
    }

    public void setPromptContent(String promptContent) {
        this.promptContent = promptContent;
    }

    public PromptContentRequestObj(String promptContent) {
        this.promptContent = promptContent;
    }
}
