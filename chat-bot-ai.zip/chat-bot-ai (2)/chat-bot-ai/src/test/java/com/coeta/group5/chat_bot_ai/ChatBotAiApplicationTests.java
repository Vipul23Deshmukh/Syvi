package com.coeta.group5.chat_bot_ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatBotAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
